#include <iostream>


int main() {
    std::cout << "a"'
    return 0;
}